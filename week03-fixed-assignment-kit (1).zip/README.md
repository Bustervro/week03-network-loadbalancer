# Week 03 — Network Load Balancer

**Project files:** [week03-network-loadbalancer/](week03-network-loadbalancer/) — Docker Compose, Nginx, Python, network diagram, audit, QA, and video recording guide.

**Automated Docker tests without Codespaces:** The workflow [`.github/workflows/qa.yml`](.github/workflows/qa.yml) can run on GitHub Actions. Select **Actions → Docker QA → Run workflow**. Wait for the result before saying tests passed.

**Existing observed tests:** Earlier Codespaces sessions returned HTTP 200 for load balancing, failover, recovery and the health endpoint. See [QA details](week03-network-loadbalancer/qa-results.md). The browser Console was only partially checked.

**Submission:** Repo https://github.com/Bustervro/week03-network-loadbalancer ; video link must be added after the student's 5–7 minute webcam + screen recording. Live URL: N/A (development Docker topology).
