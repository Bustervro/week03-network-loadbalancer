# Week 5 — Network Security

## Goal
Confirm only Nginx exposes a host port and document security limitations.

## Steps performed / verification checklist
- [ ] Create and assign the GitHub issue before starting work.
- [ ] Create the `week5-security` branch from main.
- [ ] Run or review: `docker compose ps`
- [ ] Verify published ports; inspect configuration for unnecessary exposure.
- [ ] Save screenshot(s) or logs of real results.
- [ ] Open a pull request and request review.

## Test evidence
Date: TODO
Commands actually run: TODO
Expected result: TODO
Actual result: TODO
Pass / Fail / Not run: Not run
Screenshot link: TODO

## Development update (fill in after working)
**Total hours actually spent:** TODO (do not invent hours)

**Task breakdown:**
- Issue work: TODO hours
- Testing and documentation: TODO hours
- Code review: TODO hours

**Assigned issue:** TODO (link)
**Progress summary:** TODO (what changed and what worked)
**Key learnings:** I learned why internal services should not expose host ports.
**Additional information / blockers:** TODO
**Branch:** TODO (link)
**Pull request:** TODO (link)
**PR progress and learnings:** TODO
**Wiki check:** TODO (state whether wiki instructions changed; link actual update if yes)

**PR review 1:** TODO link — actual feedback, test evidence and learning
**PR review 2:** TODO link — actual feedback, test evidence and learning

**Next step:** TODO
