# Week 7 — Continuous Integration

## Goal
Use GitHub Actions to run basic smoke tests on push and pull request.

## Steps performed / verification checklist
- [ ] Create and assign the GitHub issue before starting work.
- [ ] Create the `week7-ci` branch from main.
- [ ] Run or review: `Open Actions after pushing .github/workflows/week7-smoke.yml`
- [ ] Check logs and capture the actual job result; troubleshoot if needed.
- [ ] Save screenshot(s) or logs of real results.
- [ ] Open a pull request and request review.

## Test evidence
Date: TODO
Commands actually run: TODO
Expected result: TODO
Actual result: TODO
Pass / Fail / Not run: Not run
Screenshot link: TODO

## Development update (fill in after working)
**Total hours actually spent:** TODO (do not invent hours)

**Task breakdown:**
- Issue work: TODO hours
- Testing and documentation: TODO hours
- Code review: TODO hours

**Assigned issue:** TODO (link)
**Progress summary:** TODO (what changed and what worked)
**Key learnings:** I learned how CI provides repeatable evidence of code health.
**Additional information / blockers:** TODO
**Branch:** TODO (link)
**Pull request:** TODO (link)
**PR progress and learnings:** TODO
**Wiki check:** TODO (state whether wiki instructions changed; link actual update if yes)

**PR review 1:** TODO link — actual feedback, test evidence and learning
**PR review 2:** TODO link — actual feedback, test evidence and learning

**Next step:** TODO
