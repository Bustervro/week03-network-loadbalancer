"""Small stdlib HTTP smoke/load test; not a production benchmark."""
import argparse
import statistics
import time
import urllib.error
import urllib.request

parser = argparse.ArgumentParser()
parser.add_argument('--url', default='http://localhost:8080/healthz')
parser.add_argument('--requests', type=int, default=30)
args = parser.parse_args()
if args.requests < 1:
    parser.error('--requests must be at least 1')
latencies = []
failures = 0
for i in range(args.requests):
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(args.url, timeout=5) as response:
            status = response.status
            response.read()
        if not 200 <= status < 400:
            failures += 1
    except (urllib.error.URLError, TimeoutError, OSError):
        failures += 1
    latencies.append((time.perf_counter() - started) * 1000)
print(f'URL: {args.url}')
print(f'Requests: {args.requests}, Successes: {args.requests-failures}, Failures: {failures}')
print(f'Average latency (ms): {statistics.mean(latencies):.1f}')
print(f'Max latency (ms): {max(latencies):.1f}')
