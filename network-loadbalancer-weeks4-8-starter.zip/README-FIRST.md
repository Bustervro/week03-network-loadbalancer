# Week 4–8 starter pack

These are **starter deliverables**, not completed or verified assignments. They do not claim any tests, hours, pull requests, or reviews were done. Your practicum may require additional project-specific goals.

## Fast start
1. Create 5 issues first, each with goal and acceptance criteria, assign yourself, attach relevant sprint.
2. Copy these Markdown documents and scripts into your repository. For best GitHub traceability, make **one branch and one PR per week** instead of putting everything on main.
3. Week 4: inspect missing-route response and try taking one backend down. Week 5: `docker compose ps` and check published ports. Week 6: `python3 scripts/load_test.py`. Week 7: push the workflow, read the Actions logs. Week 8: summarize actual evidence in the report.
4. Fill in only real test results, work hours, issue/PR links, screenshot links, and two real PR reviews per week.

Important: If you upload all files at once, later branches may lack independent changes. To earn weekly credit, use separate genuine increments with real evidence. The workflow only validates Python script syntax and CLI; it does not test Docker deployment or Nginx behavior.
